package Data.Entities.Users;

public class ProviderProfile extends UserProfile{
    public ProviderProfile(String firstName, String lastName, String email, String pseudo, int number) {
        super(firstName, lastName, email, pseudo, number);
    }
}
