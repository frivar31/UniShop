package Data.Entities.Users;

public interface User {

    public UserProfile getProfile() ;

}
