package Data.Entities.Users;

public class Order {
}
